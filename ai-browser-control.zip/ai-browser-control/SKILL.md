---
name: "ai-browser-control"
description: "Control Chrome tabs with AI via AppleScript or CDP: close, open, navigate, inspect, or automate pages."
---

# AI Browser Control

Use for controlling Chrome tabs from the AI assistant. Two modes depending on what Chrome is running:

- **AppleScript mode** — works on any Chrome, no setup needed, limited to tab-level ops
- **CDP mode** — full page automation (DOM, screenshot, JS injection), requires Chrome launched with `--remote-debugging-port=9222`

## Detect which mode to use

Check if CDP is available first:
```bash
curl -s http://127.0.0.1:9222/json/version
```
- Returns JSON → CDP mode available, use `browser` tool with `profile=user`
- Empty / refused → fall back to AppleScript

## AppleScript mode

Good for: close tab, activate tab, open URL, run JS snippet in current tab.

```applescript
-- Close tab matching URL
tell application "Google Chrome"
  repeat with w in every window
    repeat with t in every tab of w
      if URL of t contains "TARGET_URL" then close t
    end repeat
  end repeat
end tell
```

Run via: `osascript -e '...'` or `osascript /tmp/script.applescript`

Common ops:
- Close by URL: `if URL of t contains "..."` → `close t`
- Close by title: `if name of t contains "..."` → `close t`
- Open URL: `open location "https://..."`
- Run JS: `execute front window's active tab javascript "..."`
- List tabs: iterate and collect `URL of t` + `name of t`

## CDP mode (browser tool, profile=user)

Requires Chrome running with a non-default user dir:
```bash
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome \
  --remote-debugging-port=9222 \
  --user-data-dir="$HOME/Library/Application Support/Google/ChromeRemoteDebug" \
  --no-first-run --no-default-browser-check
```

Then use the `browser` tool:
- `browser action=snapshot profile=user` — get current page state
- `browser action=tabs profile=user` — list open tabs
- `browser action=open url=... profile=user` — open URL
- `browser action=act profile=user` — interact with page elements
- `browser action=screenshot profile=user` — capture screenshot

## Chrome won't start with CDP?

If you see `DevTools remote debugging requires a non-default data directory`:
- The `--user-data-dir` must be a path different from `~/Library/Application Support/Google/Chrome`
- Symlinks don't work — Chrome checks realpath
- Fix: use `ChromeRemoteDebug` or any other name

If Chrome won't start (singleton lock):
```bash
rm -f ~/Library/Application\ Support/Google/ChromeRemoteDebug/SingletonLock
```

## Choosing the right approach

| What you need | Use |
|---|---|
| Close/switch/open tabs in your current Chrome | AppleScript |
| Read page content, take screenshot | CDP + browser tool |
| Click buttons, fill forms, automate flow | CDP + browser tool |
| Works without any Chrome restart | AppleScript |
