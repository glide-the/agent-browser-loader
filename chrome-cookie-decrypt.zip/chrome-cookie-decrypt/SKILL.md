---
name: "chrome-cookie-decrypt"
description: "Extract and decrypt Chrome cookies on macOS using Keychain + PBKDF2 + AES-128-CBC, or via browser-cookie3."
---

# Chrome Cookie Decrypt (macOS)

Use when you need to read Chrome cookies programmatically on macOS — e.g. to reuse a logged-in session in a script without launching Chrome.

## Key facts

- Cookie DB: `~/Library/Application Support/Google/Chrome/Default/Cookies` (SQLite)
- Encryption: `v10` prefix + AES-128-CBC, key derived via PBKDF2 from Keychain secret
- Keychain service: `Chrome Safe Storage`, account: `Chrome`
- IV: 16 space bytes (`b' ' * 16`)
- PBKDF2: SHA-1, salt `saltysalt`, 1003 iterations, dklen=16
- Padding: PKCS#7 (last byte = pad length)

## Recommended: browser-cookie3

```bash
pip install browser-cookie3
```

```python
import browser_cookie3

cj = browser_cookie3.chrome(domain_name='.example.com')
for c in cj:
    print(c.name, c.value)
```

Handles Keychain access, PBKDF2, and decryption automatically. Returns a standard `CookieJar`.

## Manual decryption

```bash
pip install pycryptodome
```

```python
import sqlite3, shutil, hashlib, subprocess
from pathlib import Path
from Crypto.Cipher import AES

# 1. Copy DB (avoids Chrome lock)
src = Path.home() / "Library/Application Support/Google/Chrome/Default/Cookies"
tmp = Path("/tmp/chrome_cookies_copy.db")
shutil.copy2(src, tmp)

# 2. Get raw key from Keychain
r = subprocess.run(
    ["security", "find-generic-password", "-w", "-a", "Chrome", "-s", "Chrome Safe Storage"],
    capture_output=True, text=True, check=True
)
raw_key = r.stdout.strip()

# 3. Derive AES key
key = hashlib.pbkdf2_hmac("sha1", raw_key.encode(), b"saltysalt", 1003, dklen=16)

# 4. Query and decrypt
conn = sqlite3.connect(tmp)
for host, name, enc in conn.execute(
    "SELECT host_key, name, encrypted_value FROM cookies WHERE host_key LIKE ?",
    ("%example.com%",)
):
    if enc[:3] == b"v10":
        raw = AES.new(key, AES.MODE_CBC, b" " * 16).decrypt(enc[3:])
        value = raw[: -raw[-1]].decode("utf-8", errors="replace")
        print(host, name, value[:60])
conn.close()
```

## Notes

- macOS will show a Keychain permission prompt on first run — click **Always Allow** to avoid repeated prompts.
- If Chrome is running, the DB may be locked; `shutil.copy2` sidesteps this.
- For non-default profiles change `Default` in the path to the profile folder name (e.g. `Profile 1`).
- `browser-cookie3` also supports Firefox and Safari.
