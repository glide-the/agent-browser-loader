# Chrome Cookie Encryption Format (macOS)

## Database

- Path: `~/Library/Application Support/Google/Chrome/<Profile>/Cookies`
- Engine: SQLite 3
- Table: `cookies`
- Columns used: `host_key`, `name`, `encrypted_value`, `path`, `expires_utc`, `is_secure`, `is_httponly`

## Encrypted value layout

```
bytes[0:3]   = b'v10'          version prefix
bytes[3:]    = AES-CBC ciphertext
```

## Key derivation

```
Keychain secret  →  PBKDF2-SHA1(password=secret, salt=b'saltysalt', iterations=1003, dklen=16)  →  16-byte AES key
```

- Keychain lookup: `security find-generic-password -w -a Chrome -s "Chrome Safe Storage"`
- The returned string is the raw password (may look like Base64 but is used as-is as UTF-8 bytes)

## IV

Fixed: `b' ' * 16` (16 ASCII space characters, 0x20)

## Padding

PKCS#7: last byte of plaintext = number of padding bytes to strip.

```python
pad_len = plaintext[-1]
value = plaintext[:-pad_len]
```

## Version history

| Prefix | Notes |
|--------|-------|
| `v10`  | Current macOS format (AES-CBC, Keychain key) |
| `v20`  | Introduced in Chrome 127+ on some platforms; uses OS-level protection (App-Bound Encryption); **not** the macOS Keychain path |

On macOS, cookies remain `v10` as of Chrome 126+.
